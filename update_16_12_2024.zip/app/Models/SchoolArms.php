<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SchoolArms extends Model
{
    use HasFactory;

    protected $fillable = [
        'arm_name',
        'active status'
    ];
}
