<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MaritalStatusController extends Controller
{
    //
}
