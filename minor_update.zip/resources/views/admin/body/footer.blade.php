<footer class="main-footer text-center">
	  &copy; 2022 <a href="#">Miedusoft Solutions</a>. All Rights Reserved.
</footer>