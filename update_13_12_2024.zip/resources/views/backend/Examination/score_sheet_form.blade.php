@extends('admin.admin_master')

@section('mainContent')

<div class="content-wrapper">
	  <div class="container-full">

	  	<section class="content">
		  <div class="box">
			<div class="box-header with-border">
			  <h4 class="box-title">School Score Sheet</h4>			  
			</div>
			<!-- /.box-header -->
			<div class="box-body">
			  <div class="row">
				<div class="col">
					<form method="get" action="{{ route('score_sheet_view') }}">
					<div class="row">
                            <div class="col-sm-2">
                                <div class="form-group">
                                    <h5>Session<span class="text-danger">*</span></h5>
                                    <div class="controls">
                                    <select name="sid" id="sid" required class="form-control p-10">
                                    <option value="">Select Session</option>                                        
                                        @foreach($SchoolSessions as $key => $Session)
                                        <option value="{{ $Session->id }}" {{ session('academic_session') == $Session->id ? 'selected' : ''}}>{{ $Session->name }}</option> 
                                        @endforeach                                       
                                    </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="form-group">
                                    <h5>Class<span class="text-danger">*</span></h5>
                                    <div class="controls">
                                    <select name="class" id="class" required class="form-control p-10">
                                        <option value="">Select Class</option>
                                        @foreach($SchoolClasses as $key => $Class)
                                        <option value="{{ $Class->id }}" {{ session('class_id') == $Class->id ? 'selected' : ''}}>{{ $Class->classname }}</option>
                                        @endforeach                                        
                                    </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="form-group">
                                    <h5>Class Arm<span class="text-danger">*</span></h5>
                                    <div class="controls">
                                    <select name="class_arm" id="class_arm" required class="form-control p-10">
                                        <option value="">Select Class Arm</option>
                                        @foreach($SchoolArms as $key => $S_Arm)
                                        <option value="{{ $S_Arm->id }}" {{ session('class_arm') == $S_Arm->id ? 'selected' : ''}}>{{ $S_Arm->arm_name }}</option>
                                        @endforeach                                        
                                    </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="form-group">
                                    <h5>Term<span class="text-danger">*</span></h5>
                                    <div class="controls">
                                    <select name="term_id" id="term" required class="form-control p-10">
                                        <option value="">Select Term</option>
                                        @foreach($SchoolTerm as $key => $Term)
                                        <option value="{{ $Term->id }}" {{ session('term_id') == $Term->id ? 'selected' : ''}}>{{ $Term->name }}</option>
                                        @endforeach                                        
                                    </select>
                                    </div>
                                </div>
                            </div>
							<div class="col-sm-3">
								<div class="form-group">									
									<div class="text-xs-right pt-25">
										<input type="submit" value="Generate Score Sheet" class="btn  btn-info">
									</div>
								</div>
							</div>
							
                        </div>                      
						
					</form>

				</div>
				<!-- /.col -->
			  </div>
			  <!-- /.row -->
			</div>
			<!-- /.box-body -->
		  </div>
		</section>
	  </div>
  </div>

@endsection