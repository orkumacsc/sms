<?php

namespace App\Http\Controllers\admin\Staff;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class QualificationsController extends Controller
{
    //
}
